#include "main.h"
#include <stdio.h>
#include <string.h>

ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;
UART_HandleTypeDef huart2;

#define ADC_SAMPLE_COUNT 10

uint16_t adc_samples[ADC_SAMPLE_COUNT];

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);

static void ADC1_Init_Registers(void);
static void DMA1_Channel1_Init_Registers(void);
static void GPIO_Button_Init_Registers(void);
static void uart_print(const char *s);

/*
 * ADC analog input:
 *   PC4  → ADC1_IN17
 * Make sure J8 pins 2 & 3 are shorted so the op-amp output is routed to PC4.
 */

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();

  uart_print("\r\nMod9 ADC+DMA Sleep demo\r\n");
  GPIO_Button_Init_Registers();
  ADC1_Init_Registers();
  DMA1_Channel1_Init_Registers();

  while (1)
  {
    /* Sleep; wake on EXTI / DMA interrupts */
    __WFI();
  }
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/* ---------- ADC1 register-level init: PC4 / ADC1_IN17 ---------- */
static void ADC1_Init_Registers(void)
{
    /* Enable GPIOC clock so we can configure PC4 as analog */
    RCC->IOPENR |= RCC_IOPENR_GPIOCEN;

    /* PC4 as analog, no pull-up/pull-down */
    GPIOC->MODER &= ~(3u << (4u * 2u));  /* clear bits */
    GPIOC->MODER |=  (3u << (4u * 2u));  /* 11b = analog mode */
    GPIOC->PUPDR &= ~(3u << (4u * 2u));  /* no pulls */

    /* Enable ADC1 clock */
    RCC->APBENR2 |= RCC_APBENR2_ADCEN;

    /* Make sure ADC is disabled before configuration */
    if (ADC1->CR & ADC_CR_ADEN)
    {
        ADC1->CR |= ADC_CR_ADDIS;
        while (ADC1->CR & ADC_CR_ADEN) {}
    }

    /* Enable ADC voltage regulator and wait a bit (~1 ms busy-wait) */
    ADC1->CR |= ADC_CR_ADVREGEN;
    for (volatile uint32_t i = 0; i < 1000; i++) {}

    /* Start ADC calibration */
    ADC1->CR |= ADC_CR_ADCAL;
    while (ADC1->CR & ADC_CR_ADCAL) {}

    /*
     * CFGR1:
     *  - DMAEN: enable DMA
     *  - CONT : continuous conversion
     *  - CHSELRMOD left at 0 (Mode 0), valid for channel 17
     */
    ADC1->CFGR1 = ADC_CFGR1_DMAEN | ADC_CFGR1_CONT;

    /* Select channel 17 (PC4 / ADC1_IN17) */
    ADC1->CHSELR = ADC_CHSELR_CHSEL17;

    /* Clear ADRDY and enable ADC */
    ADC1->ISR |= ADC_ISR_ADRDY;
    ADC1->CR  |= ADC_CR_ADEN;
    while (!(ADC1->ISR & ADC_ISR_ADRDY)) {}
}

/* ---------- DMA1 Channel1 register-level init for ADC1 ---------- */
static void DMA1_Channel1_Init_Registers(void)
{
  DMA1_Channel1->CCR &= ~DMA_CCR_EN;

  /* Peripheral address = ADC1 data register */
  DMA1_Channel1->CPAR = (uint32_t)&ADC1->DR;
  /* Memory address = adc_samples[] buffer */
  DMA1_Channel1->CMAR = (uint32_t)adc_samples;
  /* Number of halfword samples */
  DMA1_Channel1->CNDTR = ADC_SAMPLE_COUNT;

  /* Configure DMA:
   *  - MINC: increment memory
   *  - PSIZE / MSIZE = 16-bit
   *  - Direction: peripheral-to-memory (DIR=0)
   *  - TCIE: transfer complete interrupt
   */
  DMA1_Channel1->CCR = DMA_CCR_MINC
                      | DMA_CCR_PSIZE_0
                      | DMA_CCR_MSIZE_0
                      | DMA_CCR_TCIE;

  /* Route ADC1 to DMA1_Channel1 via DMAMUX */
  DMAMUX1_Channel0->CCR &= ~DMAMUX_CxCR_DMAREQ_ID_Msk;
  DMAMUX1_Channel0->CCR |= (5u << DMAMUX_CxCR_DMAREQ_ID_Pos); /* 5 = ADC1 */
}

/* ---------- Button EXTI on PC13 (unchanged) ---------- */
static void GPIO_Button_Init_Registers(void)
{
    RCC->IOPENR |= RCC_IOPENR_GPIOCEN;

    GPIOC->MODER &= ~(3u << (13 * 2));
    GPIOC->PUPDR &= ~(3u << (13 * 2));
    GPIOC->PUPDR |=  (1u << (13 * 2));   /* pull-up */

    EXTI->RTSR1 |=  (1u << 13);          /* rising edge */
    EXTI->FTSR1 &= ~(1u << 13);

    EXTI->EXTICR[3] &= ~(0xFu << 8);
    EXTI->EXTICR[3] |=  (0x2u << 8);     /* PC13 */

    EXTI->RPR1 = (1u << 13);
    EXTI->IMR1 |= (1u << 13);

    NVIC_SetPriority(EXTI4_15_IRQn, 1);
    NVIC_EnableIRQ(EXTI4_15_IRQn);
}

static void uart_print(const char *s)
{
  HAL_UART_Transmit(&huart2, (uint8_t *)s, (uint16_t)strlen(s), HAL_MAX_DELAY);
}

/* ---------- HAL-generated init functions (unchanged) ---------- */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_DMA_Init(void)
{
  __HAL_RCC_DMA1_CLK_ENABLE();

  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = USER_BUTTON_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(USER_BUTTON_GPIO_Port, &GPIO_InitStruct);

  /* This HAL-level analog config (likely PA6) is now unused for the ADC;
   * actual analog input is PC4 configured above.
   */
  GPIO_InitStruct.Pin = POTENTIONMETER_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(POTENTIONMETER_GPIO_Port, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = LED_GREEN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(LED_GREEN_GPIO_Port, &GPIO_InitStruct);
}

void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
}
#endif
