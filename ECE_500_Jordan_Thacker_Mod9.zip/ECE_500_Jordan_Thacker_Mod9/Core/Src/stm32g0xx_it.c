#include "main.h"
#include "stm32g0xx_it.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define ADC_SAMPLE_COUNT 10

extern UART_HandleTypeDef huart2;
extern uint16_t adc_samples[ADC_SAMPLE_COUNT];

void NMI_Handler(void)
{
}

void HardFault_Handler(void)
{
    while (1) {}
}

void SVC_Handler(void)
{
}

void PendSV_Handler(void)
{
}

void SysTick_Handler(void)
{
    HAL_IncTick();
}

/* EXTI for PC13 user button */
void EXTI4_15_IRQHandler(void)
{
    if (EXTI->RPR1 & (1u << 13))
    {
        EXTI->RPR1 = (1u << 13);

        /* Reset DMA transfer count and re-enable channel */
        DMA1_Channel1->CCR &= ~DMA_CCR_EN;
        DMA1_Channel1->CNDTR = ADC_SAMPLE_COUNT;
        DMA1_Channel1->CCR |= DMA_CCR_EN;

        /* Start ADC conversions */
        ADC1->CR |= ADC_CR_ADSTART;
    }
}

/* DMA1 Channel1 interrupt: 10 samples ready */
void DMA1_Channel1_IRQHandler(void)
{
    if (DMA1->ISR & DMA_ISR_TCIF1)
    {
        DMA1->IFCR = DMA_IFCR_CTCIF1;

        /* Stop ADC conversions */
        ADC1->CR |= ADC_CR_ADSTP;
        while (ADC1->CR & ADC_CR_ADSTP) {}

        /* Average 10 samples */
        uint32_t sum = 0;
        for (int i = 0; i < ADC_SAMPLE_COUNT; i++)
            sum += adc_samples[i];

        uint32_t avg = sum / ADC_SAMPLE_COUNT;

        /* Convert to millivolts assuming Vref = 3.3V and 12-bit ADC */
        uint32_t mv = (avg * 3300u) / 4095u;

        char buf[64];
        int n = sprintf(buf,
                        "ADC avg=%lu  V=%lu.%03lu\r\n",
                        (unsigned long)avg,
                        (unsigned long)(mv / 1000u),
                        (unsigned long)(mv % 1000u));

        HAL_UART_Transmit(&huart2, (const uint8_t *)buf, (uint16_t)n, HAL_MAX_DELAY);
    }
}
